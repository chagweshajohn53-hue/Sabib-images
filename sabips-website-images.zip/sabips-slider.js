/* SABIPS image slider — drop-in, no dependencies. Add class "sb-slider" to any container
   holding <figure class="sb-slide"> items. Optional: data-autoplay="5000" (ms). */
(function(){
  function init(root){
    var slides=[].slice.call(root.querySelectorAll('.sb-slide'));
    if(slides.length<2||root.dataset.ready)return; root.dataset.ready='1';
    var track=root.querySelector('.sb-track'); var i=0,timer=null;
    var delay=parseInt(root.dataset.autoplay||'0',10);
    root.setAttribute('role','region'); root.setAttribute('aria-roledescription','carousel');
    function mk(c,l,t){var b=document.createElement('button');b.type='button';b.className=c;b.setAttribute('aria-label',l);b.innerHTML=t||'';return b}
    var prev=mk('sb-prev','Previous slide','&#8249;'),next=mk('sb-next','Next slide','&#8250;');
    var dots=document.createElement('div');dots.className='sb-dots';
    var cnt=document.createElement('div');cnt.className='sb-counter';cnt.setAttribute('aria-hidden','true');
    var dotBtns=slides.map(function(_,n){var d=mk('','Go to slide '+(n+1));d.addEventListener('click',function(){go(n,true)});dots.appendChild(d);return d});
    root.appendChild(prev);root.appendChild(next);root.appendChild(dots);root.appendChild(cnt);
    function go(n,user){
      i=(n+slides.length)%slides.length; track.style.transform='translateX('+(-100*i)+'%)';
      slides.forEach(function(s,k){s.setAttribute('aria-hidden',k!==i);var im=s.querySelector('img');if(im&&Math.abs(k-i)<=1)im.loading='eager'});
      dotBtns.forEach(function(d,k){d.setAttribute('aria-current',k===i)}); cnt.textContent=(i+1)+' / '+slides.length;
      if(user)restart();
    }
    function stop(){if(timer){clearInterval(timer);timer=null}}
    function restart(){stop();if(delay&&!matchMedia('(prefers-reduced-motion: reduce)').matches)timer=setInterval(function(){go(i+1)},delay)}
    prev.addEventListener('click',function(){go(i-1,true)});next.addEventListener('click',function(){go(i+1,true)});
    root.addEventListener('mouseenter',stop);root.addEventListener('mouseleave',restart);
    root.addEventListener('focusin',stop);root.addEventListener('focusout',restart);
    root.tabIndex=0;root.addEventListener('keydown',function(e){if(e.key==='ArrowLeft')go(i-1,true);if(e.key==='ArrowRight')go(i+1,true)});
    var x0=null;
    root.addEventListener('touchstart',function(e){x0=e.touches[0].clientX;stop()},{passive:true});
    root.addEventListener('touchend',function(e){if(x0===null)return;var dx=e.changedTouches[0].clientX-x0;if(Math.abs(dx)>40)go(i+(dx<0?1:-1),true);else restart();x0=null});
    document.addEventListener('visibilitychange',function(){document.hidden?stop():restart()});
    go(0);restart();
  }
  function all(){[].forEach.call(document.querySelectorAll('.sb-slider'),init)}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',all);else all();
})();
