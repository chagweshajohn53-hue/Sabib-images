# SABIPS slider images

- `images/`  61 WebP files (avg ~110 KB, max 1600px wide). Naming: `<section>-<NN>-<what-it-shows>.webp`
- `slides.csv` / `slides.json`  filename, section, tagline, alt text, original filename for every image
- `slider-demo.html`  working preview of all 9 sections (open in a browser)
- `sabips-slider.css` + `sabips-slider.js`  dependency-free slider (arrows, dots, swipe, keyboard, auto-slide, pause on hover)

Slides 01-05 in each section are the recommended five. Slides 06-07 are reserves: use them to
replace any slide your site already shows, so a section never repeats a photo.

## Using it on the site
1. Copy `images/`, `sabips-slider.css`, `sabips-slider.js` next to your page.
2. Add `<link rel="stylesheet" href="sabips-slider.css">` in <head> and `<script src="sabips-slider.js"></script>` before </body>.
3. Replace the single image in a section with:

```html
<div class="sb-slider" data-autoplay="5000" aria-label="Damp walls project photos">
  <div class="sb-track">
    <figure class="sb-slide"><img src="images/damp-walls-01-mould-and-cracks-on-wall.webp" alt="..." loading="eager"><figcaption>Tagline here</figcaption></figure>
    <!-- repeat for slides 02-05 with loading="lazy" -->
  </div>
</div>
```
The exact markup for every section is already written in `slider-demo.html`.
